# TikDL
Simple Tiktok Video Dan Audio Downloader tanpa Watermark, Source ini sebagai media pembelajaran tentang NodeJS (JANGAN DIJUAL), Kembangkan sendiri agar lebih mudah dimengerti

## Run locally

Clone the repo and run:

### `npm install`

### `npm start`

### Features
* Download No Watermark ✅
* Download Audio ✅
* Lightweight for servers 😁
